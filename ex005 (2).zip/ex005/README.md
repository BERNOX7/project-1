echo "# project-1" >> README.md 
git init 
git add README.md 
git commit -m "first commit" 
git branch -M main 
git remote add origin https://github.com/BERNOX7/project-1. git
 git push -u origem principal
 